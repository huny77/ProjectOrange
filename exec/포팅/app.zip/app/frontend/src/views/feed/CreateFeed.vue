<template>
  <div>
    <CreateFeedForm />
  </div>
</template>

<script>
import CreateFeedForm from '@/components/challenge/CreateFeedForm.vue'
export default {
  name: 'CreateFeed',
  components: {
    CreateFeedForm,
  }
}
</script>

<style>

</style>