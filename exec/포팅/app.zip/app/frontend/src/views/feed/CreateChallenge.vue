<template>
  <div>
    <CreateChallengeForm />
  </div>
</template>

<script>
import CreateChallengeForm from '@/components/challenge/CreateChallengeForm.vue'

export default {
  name: 'CreateChallenge',
  components: {
    CreateChallengeForm,
  }
}
</script>

<style>

</style>