<template>
  <div>
    <FeedForm />
  </div>
  
</template>

<script>
import FeedForm from '@/components/challenge/FeedForm.vue'

export default {
  name: 'ChallengeFeed',
  components: {
    FeedForm,
  }
}
</script>

<style>

</style>