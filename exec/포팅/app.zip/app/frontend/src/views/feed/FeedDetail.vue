<template>
  <div>
    <FeedDetailForm />
  </div>
</template>

<script>
import FeedDetailForm from '@/components/user/FeedDetailForm'
export default {
  name: 'FeedDetail',
  components: {
    FeedDetailForm,
  }
}
</script>

<style>

</style>