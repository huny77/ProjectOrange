<template>
  <div>
    <RankingForm />
  </div>
</template>

<script>
import RankingForm from '@/components/challenge/RankingForm.vue'
export default {
  name: 'Ranking',
  components: {
    RankingForm,
  }
}
</script>

<style>

</style>