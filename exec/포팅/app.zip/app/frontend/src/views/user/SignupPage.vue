<template>
  <div>
    <SignupForm />
  </div>
</template>

<script>
import SignupForm from '@/components/user/SignupForm.vue';

export default {
  name: "Signup",
  components: {
    SignupForm,
  }
}
</script>

<style>

</style>