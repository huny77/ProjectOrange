module.exports = {
  devServer: {
    overlay: false,
  },

  transpileDependencies: ["vuetify"],
};
